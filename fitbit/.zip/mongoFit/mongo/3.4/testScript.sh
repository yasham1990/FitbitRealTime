#!/bin/bash

mongod &
/wait-for-it.sh localhost:27017
mongoimport --db fitbit --collection food_data --file products_new.json
apt-get update
apt-get -y install nodejs
apt-get -y install npm
ln -s /usr/bin/nodejs /usr/bin/node
node FoodRecommendation/bin/www

