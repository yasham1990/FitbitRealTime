#!/bin/bash
cd /fitbit
pip install tornado
pip install Flask-DebugToolbar
pip install requests
pip install requests-oauthlib
pip install Flask-OAuthlib
pip install humanize
pip install python-dateutil
pip install numpy
pip install Flask-SQLAlchemy
pip install Flask-Bcrypt
pip install Flask-PyMongo
pip install PyMySQL
python application.py
